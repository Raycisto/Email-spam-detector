package com.example.gmailspamdetector.ui.dashboard

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.gmailspamdetector.databinding.FragmentDashboardBinding
import com.example.gmailspamdetector.utils.hide
import com.example.gmailspamdetector.utils.show
import com.example.gmailspamdetector.utils.toRelativeDateString
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val viewModel: DashboardViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, s: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupChart()
        binding.btnScan.setOnClickListener { viewModel.startScan() }
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.loadStats()
            binding.swipeRefresh.isRefreshing = false
        }

        // repeatOnLifecycle cancels collectors automatically when view is STOPPED
        // preventing NullPointerException on _binding after view is destroyed
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.stats.collect { s ->
                        _binding?.let { b ->
                            b.tvWelcome.text  = "Hello, ${s.userName}"
                            b.tvTotal.text    = s.total.toString()
                            b.tvSpam.text     = s.spam.toString()
                            b.tvThreat.text   = s.threat.toString()
                            b.tvSafe.text     = s.safe.toString()
                            b.tvLastScan.text = if (s.lastScanTime > 0)
                                "Last scan: ${s.lastScanTime.toRelativeDateString()}"
                            else "Never scanned"
                            updateChart(s)
                        }
                    }
                }
                launch {
                    viewModel.isScanning.collect { scanning ->
                        _binding?.let { b ->
                            if (scanning) { b.scanProgress.show(); b.btnScan.isEnabled = false }
                            else          { b.scanProgress.hide(); b.btnScan.isEnabled = true  }
                        }
                    }
                }
            }
        }
    }

    private fun setupChart() {
        _binding?.pieChart?.apply {
            description.isEnabled = false
            setUsePercentValues(true)
            isDrawHoleEnabled = true
            holeRadius = 58f
            setHoleColor(android.graphics.Color.TRANSPARENT)
            legend.isEnabled = true
            setEntryLabelColor(android.graphics.Color.WHITE)
        }
    }

    private fun updateChart(s: DashboardStats) {
        val b = _binding ?: return
        if (s.total == 0) { b.pieChart.hide(); return }
        b.pieChart.show()
        val entries = mutableListOf<PieEntry>()
        if (s.safe   > 0) entries.add(PieEntry(s.safe.toFloat(),   "Safe"))
        if (s.spam   > 0) entries.add(PieEntry(s.spam.toFloat(),   "Spam"))
        if (s.threat > 0) entries.add(PieEntry(s.threat.toFloat(), "Threat"))
        val dataSet = PieDataSet(entries, "").apply {
            colors = listOf(0xFF00E676.toInt(), 0xFFFF6B35.toInt(), 0xFFFF1744.toInt())
            valueTextColor = android.graphics.Color.WHITE
            valueTextSize = 12f; sliceSpace = 3f
        }
        b.pieChart.data = PieData(dataSet)
        b.pieChart.invalidate()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
