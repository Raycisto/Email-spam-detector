package com.example.gmailspamdetector.repository

import android.util.Base64
import android.util.Log
import com.example.gmailspamdetector.data.local.EmailDao
import com.example.gmailspamdetector.data.local.EmailEntity
import com.example.gmailspamdetector.data.model.Email
import com.example.gmailspamdetector.data.remote.GmailApiService
import com.example.gmailspamdetector.data.remote.dto.Part
import com.example.gmailspamdetector.ml.SpamClassifier
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GmailRepository @Inject constructor(
    private val apiService: GmailApiService,
    private val emailDao: EmailDao,
    private val classifier: SpamClassifier
) {
    val allEmails: Flow<List<Email>> = emailDao.getAllEmails().map { it.map { e -> e.toEmail() } }
    val flaggedEmails: Flow<List<Email>> = emailDao.getFlaggedEmails().map { it.map { e -> e.toEmail() } }

    suspend fun getStats() = mapOf(
        "total"  to emailDao.getTotalCount(),
        "spam"   to emailDao.getSpamCount(),
        "threat" to emailDao.getThreatCount(),
        "safe"   to emailDao.getSafeCount()
    )

    suspend fun scanInbox(count: Int = 30): List<Email> {
        val refs = try {
            apiService.listMessages(maxResults = count).messages ?: return emptyList()
        } catch (e: Exception) {
            Log.e("GmailRepository", "Failed to list messages: ${e.message}")
            return emptyList()
        }

        val scannedEmails = mutableListOf<Email>()
        for (ref in refs) {
            try {
                val msg     = apiService.getMessage(id = ref.id)
                val headers = msg.payload?.headers ?: emptyList()
                val subject = headers.find { it.name.equals("Subject", true) }?.value ?: "(No Subject)"
                val from    = headers.find { it.name.equals("From",    true) }?.value ?: "Unknown"
                val dateStr = headers.find { it.name.equals("Date",    true) }?.value
                val date    = dateStr?.let { parseDate(it) } ?: msg.internalDate?.toLongOrNull() ?: 0L
                val (displayName, emailAddr) = parseFrom(from)
                val body    = extractBody(msg.payload?.parts, msg.payload?.body?.data)
                val result  = classifier.classify(subject, body, "$displayName <$emailAddr>")
                val email   = Email(ref.id, ref.threadId, subject, displayName,
                    emailAddr, msg.snippet ?: "", body, date)
                emailDao.upsertEmail(EmailEntity.fromEmail(email, result))
                scannedEmails.add(email.copy(scanResult = result))
            } catch (e: Exception) {
                Log.e("GmailRepository", "Error processing message ${ref.id}: ${e.message}")
            }
        }
        return scannedEmails
    }

    suspend fun getEmailById(id: String): Email? = emailDao.getEmailById(id)?.toEmail()
    suspend fun clearHistory() = emailDao.clearAll()

    private fun extractBody(parts: List<Part>?, fallbackData: String?): String {
        if (parts.isNullOrEmpty()) return fallbackData?.decodeBase64Url() ?: ""
        for (part in parts) {
            if (part.mimeType == "text/plain") {
                val d = part.body?.data
                if (!d.isNullOrEmpty()) return d.decodeBase64Url()
            }
        }
        for (part in parts) {
            if (part.mimeType?.startsWith("multipart") == true && part.parts != null) {
                val nested = extractBody(part.parts, null)
                if (nested.isNotEmpty()) return nested
            }
        }
        for (part in parts) {
            if (part.mimeType == "text/html") {
                val html = part.body?.data?.decodeBase64Url() ?: continue
                return html.replace(Regex("<[^>]+>"), " ").trim()
            }
        }
        return ""
    }

    private fun String.decodeBase64Url(): String = try {
        val bytes = Base64.decode(replace('-', '+').replace('_', '/'), Base64.DEFAULT)
        String(bytes, Charsets.UTF_8)
    } catch (_: Exception) { this }

    private fun parseFrom(from: String): Pair<String, String> {
        val match = Regex("^(.*?)<([^>]+)>$").find(from.trim())
        return if (match != null) {
            val name = match.groupValues[1].trim().removeSurrounding("\"")
            Pair(name.ifEmpty { match.groupValues[2].trim() }, match.groupValues[2].trim())
        } else Pair(from, from)
    }

    private fun parseDate(dateStr: String): Long {
        listOf("EEE, dd MMM yyyy HH:mm:ss Z","dd MMM yyyy HH:mm:ss Z","EEE, d MMM yyyy HH:mm:ss Z").forEach { fmt ->
            try { return java.text.SimpleDateFormat(fmt, java.util.Locale.ENGLISH).parse(dateStr)?.time ?: 0L }
            catch (_: Exception) {}
        }
        return 0L
    }
}
