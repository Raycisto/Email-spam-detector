package com.example.gmailspamdetector.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface EmailDao {
    @Upsert suspend fun upsertEmail(email: EmailEntity)
    @Upsert suspend fun upsertEmails(emails: List<EmailEntity>)

    @Query("SELECT * FROM scanned_emails ORDER BY scannedAt DESC")
    fun getAllEmails(): Flow<List<EmailEntity>>

    @Query("SELECT * FROM scanned_emails WHERE id = :id LIMIT 1")
    suspend fun getEmailById(id: String): EmailEntity?

    @Query("SELECT * FROM scanned_emails WHERE label != 'safe' ORDER BY scannedAt DESC")
    fun getFlaggedEmails(): Flow<List<EmailEntity>>

    @Query("SELECT COUNT(*) FROM scanned_emails")             suspend fun getTotalCount(): Int
    @Query("SELECT COUNT(*) FROM scanned_emails WHERE label = 'spam'") suspend fun getSpamCount(): Int
    @Query("SELECT COUNT(*) FROM scanned_emails WHERE label IN ('phishing','threat')") suspend fun getThreatCount(): Int
    @Query("SELECT COUNT(*) FROM scanned_emails WHERE label = 'safe'") suspend fun getSafeCount(): Int
    @Query("DELETE FROM scanned_emails") suspend fun clearAll()
    @Delete suspend fun deleteEmail(email: EmailEntity)
}
