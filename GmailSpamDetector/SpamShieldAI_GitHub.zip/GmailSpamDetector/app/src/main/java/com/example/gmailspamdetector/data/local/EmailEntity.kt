package com.example.gmailspamdetector.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.gmailspamdetector.data.model.Email
import com.example.gmailspamdetector.data.model.ScanResult

@Entity(tableName = "scanned_emails")
data class EmailEntity(
    @PrimaryKey val id: String,
    val threadId: String,
    val subject: String,
    val sender: String,
    val senderEmail: String,
    val snippet: String,
    val body: String,
    val date: Long,
    val label: String,
    val confidence: Float,
    val threatLevel: String,
    val reasons: String,
    val keywords: String,
    val urlCount: Int,
    val recommendation: String,
    val scannedAt: Long = System.currentTimeMillis()
) {
    fun toEmail(): Email = Email(
        id = id, threadId = threadId, subject = subject,
        sender = sender, senderEmail = senderEmail,
        snippet = snippet, body = body, date = date,
        scanResult = ScanResult(
            label = label, confidence = confidence,
            threatLevel = threatLevel,
            reasons = reasons.split("|").filter { it.isNotEmpty() },
            keywords = keywords.split("|").filter { it.isNotEmpty() },
            urlCount = urlCount, recommendation = recommendation
        )
    )

    companion object {
        fun fromEmail(email: Email, result: ScanResult) = EmailEntity(
            id = email.id, threadId = email.threadId,
            subject = email.subject, sender = email.sender,
            senderEmail = email.senderEmail, snippet = email.snippet,
            body = email.body, date = email.date,
            label = result.label, confidence = result.confidence,
            threatLevel = result.threatLevel,
            reasons = result.reasons.joinToString("|"),
            keywords = result.keywords.joinToString("|"),
            urlCount = result.urlCount, recommendation = result.recommendation
        )
    }
}
