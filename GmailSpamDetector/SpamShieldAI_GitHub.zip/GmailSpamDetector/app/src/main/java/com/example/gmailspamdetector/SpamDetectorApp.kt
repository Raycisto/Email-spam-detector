package com.example.gmailspamdetector

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class SpamDetectorApp : Application() {
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Threat Alerts", NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Alerts when a dangerous email is detected" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    companion object { const val CHANNEL_ID = "spam_detector_alerts" }
}
