package com.example.gmailspamdetector.data.model

data class Email(
    val id: String,
    val threadId: String,
    val subject: String,
    val sender: String,
    val senderEmail: String,
    val snippet: String,
    val body: String,
    val date: Long,
    val isRead: Boolean = false,
    val scanResult: ScanResult? = null
)
