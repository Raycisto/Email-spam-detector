package com.example.gmailspamdetector.ui.inbox

import android.os.Bundle
import android.view.*
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.gmailspamdetector.R
import com.example.gmailspamdetector.databinding.FragmentInboxBinding
import com.example.gmailspamdetector.utils.hide
import com.example.gmailspamdetector.utils.show
import com.example.gmailspamdetector.utils.toast
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class InboxFragment : Fragment() {
    private var _binding: FragmentInboxBinding? = null
    private val binding get() = _binding!!
    private val viewModel: InboxViewModel by viewModels()
    private lateinit var adapter: EmailAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        _binding = FragmentInboxBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = EmailAdapter { email ->
            findNavController().navigate(
                R.id.action_inboxFragment_to_emailDetailFragment,
                bundleOf("emailId" to email.id)
            )
        }
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@InboxFragment.adapter
        }
        binding.btnScanInbox.setOnClickListener { viewModel.scanInbox() }
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.scanInbox()
            binding.swipeRefresh.isRefreshing = false
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { state ->
                    val b = _binding ?: return@collect
                    when (state) {
                        is InboxUiState.Idle -> {
                            b.progressBar.hide(); b.recyclerView.hide(); b.tvEmpty.show()
                        }
                        is InboxUiState.Loading -> {
                            b.progressBar.show(); b.recyclerView.hide(); b.tvEmpty.hide()
                        }
                        is InboxUiState.Success -> {
                            b.progressBar.hide(); b.tvEmpty.hide(); b.recyclerView.show()
                            b.tvScanCount.text = "${state.emails.size} emails scanned"
                            adapter.submitList(state.emails)
                        }
                        is InboxUiState.Error -> {
                            b.progressBar.hide(); b.tvEmpty.show(); b.recyclerView.hide()
                            b.tvEmptyText.text = state.message
                            context?.toast(state.message)
                        }
                    }
                }
            }
        }
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
