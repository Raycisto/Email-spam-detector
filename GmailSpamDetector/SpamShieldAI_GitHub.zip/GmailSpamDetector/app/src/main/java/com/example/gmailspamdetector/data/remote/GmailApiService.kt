package com.example.gmailspamdetector.data.remote

import com.example.gmailspamdetector.data.remote.dto.MessageListResponse
import com.example.gmailspamdetector.data.remote.dto.MessageResponse
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface GmailApiService {
    @GET("gmail/v1/users/{userId}/messages")
    suspend fun listMessages(
        @Path("userId")      userId: String = "me",
        @Query("maxResults") maxResults: Int = 30,
        @Query("q")          q: String = "in:inbox"
    ): MessageListResponse

    @GET("gmail/v1/users/{userId}/messages/{id}")
    suspend fun getMessage(
        @Path("userId")  userId: String = "me",
        @Path("id")      id: String,
        @Query("format") format: String = "full"
    ): MessageResponse
}
