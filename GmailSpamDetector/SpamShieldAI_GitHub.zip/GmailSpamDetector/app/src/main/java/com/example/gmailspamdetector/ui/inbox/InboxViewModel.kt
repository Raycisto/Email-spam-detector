package com.example.gmailspamdetector.ui.inbox

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gmailspamdetector.data.model.Email
import com.example.gmailspamdetector.repository.GmailRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class InboxUiState {
    object Idle    : InboxUiState()
    object Loading : InboxUiState()
    data class Success(val emails: List<Email>) : InboxUiState()
    data class Error(val message: String)       : InboxUiState()
}

@HiltViewModel
class InboxViewModel @Inject constructor(private val repository: GmailRepository) : ViewModel() {
    private val _uiState = MutableStateFlow<InboxUiState>(InboxUiState.Idle)
    val uiState: StateFlow<InboxUiState> = _uiState

    init {
        viewModelScope.launch {
            repository.allEmails.collect { emails ->
                if (_uiState.value !is InboxUiState.Loading)
                    _uiState.value = if (emails.isEmpty()) InboxUiState.Idle else InboxUiState.Success(emails)
            }
        }
    }

    fun scanInbox() {
        viewModelScope.launch {
            _uiState.value = InboxUiState.Loading
            try {
                val emails = repository.scanInbox(30)
                if (emails.isEmpty()) _uiState.value = InboxUiState.Error("No messages found. Check Gmail permissions.")
            } catch (e: Exception) {
                _uiState.value = InboxUiState.Error(e.message ?: "Failed to scan inbox")
            }
        }
    }
}
