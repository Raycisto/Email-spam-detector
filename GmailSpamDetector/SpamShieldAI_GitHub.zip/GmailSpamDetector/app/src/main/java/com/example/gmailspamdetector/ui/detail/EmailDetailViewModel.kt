package com.example.gmailspamdetector.ui.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gmailspamdetector.data.model.Email
import com.example.gmailspamdetector.repository.GmailRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class EmailDetailViewModel @Inject constructor(private val repository: GmailRepository) : ViewModel() {
    private val _email = MutableStateFlow<Email?>(null)
    val email: StateFlow<Email?> = _email
    fun loadEmail(id: String) { viewModelScope.launch { _email.value = repository.getEmailById(id) } }
}
