package com.example.gmailspamdetector.auth

import android.content.Context
import android.util.Log
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GoogleAuthManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        const val GMAIL_SCOPE = "https://www.googleapis.com/auth/gmail.readonly"
        // Web Client ID — required for Google Sign-In to work correctly
        private const val WEB_CLIENT_ID =
            "YOUR_WEB_CLIENT_ID.apps.googleusercontent.com"
        private const val TAG = "GoogleAuthManager"
    }

    fun buildSignInClient(): GoogleSignInClient {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestProfile()
            .requestIdToken(WEB_CLIENT_ID)        // ← needed for auth
            .requestServerAuthCode(WEB_CLIENT_ID) // ← needed for API token exchange
            .requestScopes(Scope(GMAIL_SCOPE))
            .build()
        return GoogleSignIn.getClient(context, gso)
    }

    fun getSignedInAccount(): GoogleSignInAccount? =
        GoogleSignIn.getLastSignedInAccount(context)

    fun isSignedIn(): Boolean = getSignedInAccount() != null

    /** Fetch Gmail OAuth2 access token on IO thread. Returns null on failure. */
    suspend fun getAccessToken(): String? = withContext(Dispatchers.IO) {
        try {
            val account = getSignedInAccount() ?: return@withContext null
            val androidAccount = account.account ?: return@withContext null
            com.google.android.gms.auth.GoogleAuthUtil.getToken(
                context, androidAccount, "oauth2:$GMAIL_SCOPE"
            ).also { Log.d(TAG, "Access token retrieved successfully") }
        } catch (e: com.google.android.gms.auth.UserRecoverableAuthException) {
            Log.w(TAG, "User needs to grant permission: ${e.message}")
            null
        } catch (e: Exception) {
            Log.e(TAG, "getAccessToken failed: ${e.message}")
            null
        }
    }

    suspend fun signOut() {
        try {
            buildSignInClient().signOut().await()
            Log.d(TAG, "Signed out")
        } catch (e: Exception) {
            Log.e(TAG, "Sign-out error: ${e.message}")
        }
    }
}
