package com.example.gmailspamdetector.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gmailspamdetector.repository.GmailRepository
import com.example.gmailspamdetector.utils.SecurePreferences
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class DashboardStats(val total:Int=0, val spam:Int=0, val threat:Int=0,
    val safe:Int=0, val lastScanTime:Long=0L, val userName:String="")

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val repository: GmailRepository,
    private val prefs: SecurePreferences
) : ViewModel() {
    private val _stats = MutableStateFlow(DashboardStats())
    val stats: StateFlow<DashboardStats> = _stats
    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    init { loadStats() }

    fun loadStats() {
        viewModelScope.launch {
            val map = repository.getStats()
            _stats.value = DashboardStats(map["total"]?:0, map["spam"]?:0,
                map["threat"]?:0, map["safe"]?:0, prefs.lastScanTime, prefs.userName?:"User")
        }
    }

    fun startScan() {
        viewModelScope.launch {
            _isScanning.value = true
            try { repository.scanInbox(30); prefs.lastScanTime = System.currentTimeMillis(); loadStats() }
            catch (e: Exception) { e.printStackTrace() }
            finally { _isScanning.value = false }
        }
    }
}
