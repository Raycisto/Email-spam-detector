package com.example.gmailspamdetector.ml

import com.example.gmailspamdetector.data.model.ScanResult
import java.net.URL
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.min

@Singleton
class SpamClassifier @Inject constructor() {

    private val spamWeights = mapOf(
        "win" to 12f, "winner" to 18f, "prize" to 16f, "free gift" to 20f,
        "claim now" to 22f, "congratulations" to 14f, "limited time" to 16f,
        "act now" to 18f, "click here" to 18f, "reward" to 12f,
        "gift card" to 18f, "lottery" to 24f, "million dollars" to 24f,
        "inheritance" to 20f, "nigerian prince" to 30f, "wire transfer" to 20f,
        "100% free" to 22f, "make money" to 16f, "work from home" to 14f,
        "earn extra" to 16f, "guaranteed" to 12f, "cash prize" to 22f,
        "double your" to 18f, "incredible deal" to 16f, "buy now" to 10f
    )

    private val phishingWeights = mapOf(
        "verify your account" to 30f, "confirm your password" to 30f,
        "reset your password" to 20f, "update your information" to 22f,
        "account will be suspended" to 30f, "account suspended" to 28f,
        "account locked" to 26f, "login immediately" to 26f,
        "suspicious activity" to 22f, "unusual login" to 22f,
        "unauthorized access" to 24f, "verify your identity" to 26f,
        "confirm your identity" to 26f, "enter your credentials" to 28f,
        "enter your password" to 28f, "click to verify" to 26f,
        "validate your account" to 26f, "dear customer" to 14f,
        "dear valued" to 14f, "credit card number" to 26f,
        "social security" to 28f, "security alert" to 18f
    )

    private val threatWeights = mapOf(
        "virus" to 22f, "malware" to 26f, "ransomware" to 30f,
        "hacked" to 22f, "compromised" to 22f, "data leaked" to 24f,
        "we have access" to 22f, "send bitcoin" to 28f,
        "extortion" to 28f, "blackmail" to 28f, "pay or" to 20f,
        "legal action" to 16f, "you are being watched" to 28f,
        "your camera" to 18f, "your password is" to 26f
    )

    private val suspiciousDomains = setOf(
        "bit.ly","tinyurl.com","goo.gl","ow.ly","t.co",
        "is.gd","buff.ly","adf.ly","sh.st","bc.vc"
    )

    private val phishingDomainPatterns = listOf(
        Regex("paypal[.-].*\\.com"), Regex("amazon[.-].*\\.com"),
        Regex("apple[.-].*\\.com"),  Regex("google[.-].*\\.com"),
        Regex("microsoft[.-].*\\.com"), Regex("secure[.-].*login"),
        Regex("account[.-].*verify")
    )

    private val urgencyPhrases = listOf(
        "urgent","immediately","right now","asap","expire",
        "expiring soon","last chance","today only","within 24 hours",
        "within 48 hours","respond immediately","action required",
        "important notice","do not ignore","final warning"
    )

    fun classify(subject: String, body: String, sender: String): ScanResult {
        val fullText = "$subject $body".lowercase().trim()
        var spamScore = 0f; var phishingScore = 0f; var threatScore = 0f
        val reasons = mutableListOf<String>()
        val foundKeywords = mutableListOf<String>()

        spamWeights.forEach    { (kw, w) -> if (fullText.contains(kw)) { spamScore += w;     foundKeywords += kw } }
        phishingWeights.forEach{ (kw, w) -> if (fullText.contains(kw)) { phishingScore += w; foundKeywords += kw } }
        threatWeights.forEach  { (kw, w) -> if (fullText.contains(kw)) { threatScore += w;   foundKeywords += kw } }

        val urlRegex = Regex("""https?://[^\s<>"']+""")
        val urls = urlRegex.findAll(fullText).map { it.value }.toList()
        val urlCount = urls.size
        if (urlCount > 5) { spamScore += urlCount * 4f; reasons += "Contains $urlCount URLs" }

        urls.forEach { rawUrl ->
            try {
                val host = URL(rawUrl).host.lowercase()
                if (suspiciousDomains.any { host.endsWith(it) }) {
                    spamScore += 18f; reasons += "Short-link service: $host"
                }
                phishingDomainPatterns.forEach { p ->
                    if (p.containsMatchIn(host)) { phishingScore += 25f; reasons += "Spoofed domain: $host" }
                }
                if (host.matches(Regex("""\d{1,3}(\.\d{1,3}){3}"""))) {
                    phishingScore += 28f; reasons += "Link points to raw IP address"
                }
            } catch (_: Exception) {}
        }

        val words = fullText.split(Regex("\\s+"))
        val upperWords = words.count { it.length > 3 && it == it.uppercase() && it.any { c -> c.isLetter() } }
        val capsRatio = upperWords.toFloat() / words.size.coerceAtLeast(1)
        if (capsRatio > 0.25f) { spamScore += 14f; reasons += "Excessive ALL CAPS (${"%.0f".format(capsRatio*100)}%)" }

        val exclamations = fullText.count { it == '!' }
        if (exclamations >= 3) { spamScore += min(exclamations * 3f, 18f); reasons += "Heavy exclamation use ($exclamations)" }

        val urgencyHits = urgencyPhrases.filter { fullText.contains(it) }
        if (urgencyHits.isNotEmpty()) {
            val boost = urgencyHits.size * 8f
            spamScore += boost; phishingScore += boost * 0.5f
            reasons += "Urgency: ${urgencyHits.take(3).joinToString(", ")}"
            foundKeywords += urgencyHits.take(3)
        }

        val senderLower = sender.lowercase()
        val senderDomain = Regex("[a-zA-Z0-9._%+\\-]+@([a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,})")
            .find(senderLower)?.groupValues?.get(1) ?: ""
        if (senderDomain.isNotEmpty()) {
            val free = listOf("gmail.com","yahoo.com","hotmail.com","outlook.com")
            val biz  = listOf("bank","paypal","amazon","apple","google","netflix","microsoft")
            if (free.any { senderDomain.endsWith(it) } && biz.any { fullText.contains(it) }) {
                phishingScore += 24f; reasons += "Business email from free provider ($senderDomain)"
            }
        }

        return buildResult(spamScore, phishingScore, threatScore, urlCount, reasons, foundKeywords.distinct().take(10))
    }

    private fun buildResult(
        spamScore: Float, phishingScore: Float, threatScore: Float,
        urlCount: Int, reasons: MutableList<String>, keywords: List<String>
    ): ScanResult {
        fun squash(s: Float) = min(s / (s + 60f) * 100f, 99f)
        val ss = squash(spamScore); val ps = squash(phishingScore); val ts = squash(threatScore)
        return when {
            ps >= 55f -> ScanResult("phishing",  ps, "critical", reasons, keywords, urlCount, "delete")
            ts >= 50f -> ScanResult("threat",     ts, "high",     reasons, keywords, urlCount, "delete")
            ss >= 50f -> ScanResult("spam",       ss, "medium",   reasons, keywords, urlCount, "mark_spam")
            maxOf(ss,ps,ts) >= 25f -> ScanResult("suspicious", maxOf(ss,ps,ts), "low", reasons, keywords, urlCount, "verify")
            else -> ScanResult("safe", 100f - maxOf(ss,ps,ts), "none", emptyList(), emptyList(), urlCount, "ignore")
        }
    }
}
