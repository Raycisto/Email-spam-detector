package com.example.gmailspamdetector.di

import com.example.gmailspamdetector.auth.GoogleAuthManager
import com.example.gmailspamdetector.data.remote.GmailApiService
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    private const val GMAIL_BASE_URL = "https://www.googleapis.com/"

    @Provides @Singleton
    fun provideAuthInterceptor(authManager: GoogleAuthManager): Interceptor =
        Interceptor { chain ->
            val token = runBlocking {
                try { authManager.getAccessToken() }
                catch (e: Exception) {
                    android.util.Log.e("AuthInterceptor", "Token error: ${e.message}")
                    null
                }
            }
            val request = if (!token.isNullOrEmpty())
                chain.request().newBuilder().addHeader("Authorization", "Bearer $token").build()
            else chain.request()
            chain.proceed(request)
        }

    @Provides @Singleton
    fun provideOkHttpClient(authInterceptor: Interceptor): OkHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            })
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .build()

    @Provides @Singleton
    fun provideRetrofit(okHttpClient: OkHttpClient): Retrofit =
        Retrofit.Builder()
            .baseUrl(GMAIL_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()

    @Provides @Singleton
    fun provideGmailApiService(retrofit: Retrofit): GmailApiService =
        retrofit.create(GmailApiService::class.java)
}
