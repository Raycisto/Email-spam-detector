package com.example.gmailspamdetector.ui.settings

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.gmailspamdetector.auth.GoogleAuthManager
import com.example.gmailspamdetector.databinding.FragmentSettingsBinding
import com.example.gmailspamdetector.ui.login.LoginActivity
import com.example.gmailspamdetector.utils.SecurePreferences
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class SettingsFragment : Fragment() {
    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!
    @Inject lateinit var prefs: SecurePreferences
    @Inject lateinit var authManager: GoogleAuthManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false); return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvUserEmail.text = prefs.userEmail ?: "Not signed in"
        binding.switchDarkMode.isChecked = prefs.isDarkMode
        binding.switchAutoScan.isChecked = prefs.isAutoScanEnabled
        binding.switchNotify.isChecked   = prefs.isNotifyThreats
        binding.switchDarkMode.setOnCheckedChangeListener { _, c ->
            prefs.isDarkMode = c
            AppCompatDelegate.setDefaultNightMode(if (c) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO)
        }
        binding.switchAutoScan.setOnCheckedChangeListener { _, c -> prefs.isAutoScanEnabled = c }
        binding.switchNotify.setOnCheckedChangeListener   { _, c -> prefs.isNotifyThreats = c }
        binding.btnLogout.setOnClickListener {
            lifecycleScope.launch {
                authManager.signOut(); prefs.clearAll()
                startActivity(Intent(requireContext(), LoginActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
