package com.example.gmailspamdetector.ui.history

import android.os.Bundle
import android.view.*
import androidx.appcompat.app.AlertDialog
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.gmailspamdetector.R
import com.example.gmailspamdetector.databinding.FragmentHistoryBinding
import com.example.gmailspamdetector.utils.hide
import com.example.gmailspamdetector.utils.show
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class HistoryFragment : Fragment() {
    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding!!
    private val viewModel: HistoryViewModel by viewModels()
    private lateinit var adapter: HistoryAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, s: Bundle?): View {
        _binding = FragmentHistoryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setHasOptionsMenu(true)
        adapter = HistoryAdapter { email ->
            findNavController().navigate(
                R.id.action_historyFragment_to_emailDetailFragment,
                bundleOf("emailId" to email.id)
            )
        }
        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = this@HistoryFragment.adapter
        }
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.emails.collect { emails ->
                    val b = _binding ?: return@collect
                    if (emails.isEmpty()) {
                        b.recyclerView.hide(); b.tvEmpty.show(); b.tvCount.text = ""
                    } else {
                        b.tvEmpty.hide(); b.recyclerView.show()
                        adapter.submitList(emails)
                        b.tvCount.text = "${emails.size} flagged email(s)"
                    }
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.history_menu, menu)
    }

    @Deprecated("Deprecated in Java")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_clear) {
            AlertDialog.Builder(requireContext())
                .setTitle("Clear History")
                .setMessage("Delete all scan history?")
                .setPositiveButton("Clear") { _, _ -> viewModel.clearHistory() }
                .setNegativeButton("Cancel", null).show()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
