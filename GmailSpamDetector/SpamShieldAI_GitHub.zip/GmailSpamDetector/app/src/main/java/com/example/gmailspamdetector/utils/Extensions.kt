package com.example.gmailspamdetector.utils

import android.content.Context
import android.view.View
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.*

fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
fun View.show()      { visibility = View.VISIBLE }
fun View.hide()      { visibility = View.GONE }
fun View.invisible() { visibility = View.INVISIBLE }

fun Long.toRelativeDateString(): String {
    val cal   = Calendar.getInstance().apply { timeInMillis = this@toRelativeDateString }
    val today = Calendar.getInstance()
    val yest  = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    fun same(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
        a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)
    return when {
        same(cal, today) -> SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(this))
        same(cal, yest)  -> "Yesterday"
        else             -> SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(this))
    }
}

fun String.decodeBase64(): String = try {
    val bytes = android.util.Base64.decode(
        replace('-', '+').replace('_', '/'), android.util.Base64.DEFAULT)
    String(bytes, Charsets.UTF_8)
} catch (e: Exception) { this }

fun String.initials(): String {
    val parts = trim().split(" ").filter { it.isNotEmpty() }
    return when {
        parts.size >= 2 -> "${parts[0][0]}${parts[1][0]}".uppercase()
        parts.size == 1 && parts[0].isNotEmpty() -> parts[0][0].uppercaseChar().toString()
        else -> "?"
    }
}
