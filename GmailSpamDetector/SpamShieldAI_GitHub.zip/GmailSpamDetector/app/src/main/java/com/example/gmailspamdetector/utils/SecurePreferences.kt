package com.example.gmailspamdetector.utils

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SecurePreferences @Inject constructor(
    @ApplicationContext context: Context
) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context, "spam_detector_secure_prefs", masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    companion object {
        private const val KEY_USER_EMAIL    = "user_email"
        private const val KEY_USER_NAME     = "user_name"
        private const val KEY_AUTO_SCAN     = "auto_scan"
        private const val KEY_DARK_MODE     = "dark_mode"
        private const val KEY_NOTIFY_THREAT = "notify_threat"
        private const val KEY_LAST_SCAN_MS  = "last_scan_ms"
    }

    var userEmail: String?
        get() = prefs.getString(KEY_USER_EMAIL, null)
        set(v) = prefs.edit().putString(KEY_USER_EMAIL, v).apply()

    var userName: String?
        get() = prefs.getString(KEY_USER_NAME, null)
        set(v) = prefs.edit().putString(KEY_USER_NAME, v).apply()

    var isAutoScanEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_SCAN, false)
        set(v) = prefs.edit().putBoolean(KEY_AUTO_SCAN, v).apply()

    var isDarkMode: Boolean
        get() = prefs.getBoolean(KEY_DARK_MODE, true)
        set(v) = prefs.edit().putBoolean(KEY_DARK_MODE, v).apply()

    var isNotifyThreats: Boolean
        get() = prefs.getBoolean(KEY_NOTIFY_THREAT, true)
        set(v) = prefs.edit().putBoolean(KEY_NOTIFY_THREAT, v).apply()

    var lastScanTime: Long
        get() = prefs.getLong(KEY_LAST_SCAN_MS, 0L)
        set(v) = prefs.edit().putLong(KEY_LAST_SCAN_MS, v).apply()

    fun clearAll() = prefs.edit().clear().apply()
}
