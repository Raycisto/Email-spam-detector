package com.example.gmailspamdetector.ui.history

import android.graphics.Color
import android.view.*
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.gmailspamdetector.R
import com.example.gmailspamdetector.data.model.Email
import com.example.gmailspamdetector.databinding.ItemHistoryBinding
import com.example.gmailspamdetector.utils.toRelativeDateString

class HistoryAdapter(private val onClick: (Email) -> Unit)
    : ListAdapter<Email, HistoryAdapter.VH>(Diff()) {

    inner class VH(private val b: ItemHistoryBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(e: Email) {
            b.tvSubject.text = e.subject.ifEmpty { "(No Subject)" }
            b.tvSender.text  = e.senderEmail
            b.tvDate.text    = e.date.toRelativeDateString().uppercase()
            val r = e.scanResult
            when (r?.label) {
                "phishing", "threat" -> {
                    b.tvLabel.text = if (r.label == "phishing") "PHISHING" else "THREAT"
                    b.tvLabel.setTextColor(Color.parseColor("#FF3B30"))
                    b.tvLabel.setBackgroundResource(R.drawable.bg_badge_danger)
                    b.progressBar.progressTintList =
                        android.content.res.ColorStateList.valueOf(Color.parseColor("#FF3B30"))
                }
                "spam" -> {
                    b.tvLabel.text = "SPAM"
                    b.tvLabel.setTextColor(Color.parseColor("#FF9F0A"))
                    b.tvLabel.setBackgroundResource(R.drawable.bg_badge_spam)
                    b.progressBar.progressTintList =
                        android.content.res.ColorStateList.valueOf(Color.parseColor("#FF9F0A"))
                }
                "suspicious" -> {
                    b.tvLabel.text = "SUSPICIOUS"
                    b.tvLabel.setTextColor(Color.parseColor("#FFD60A"))
                    b.tvLabel.setBackgroundResource(R.drawable.bg_badge_suspicious)
                    b.progressBar.progressTintList =
                        android.content.res.ColorStateList.valueOf(Color.parseColor("#FFD60A"))
                }
                else -> {
                    b.tvLabel.text = "SAFE"
                    b.tvLabel.setTextColor(Color.parseColor("#34C759"))
                    b.tvLabel.setBackgroundResource(R.drawable.bg_badge_safe)
                    b.progressBar.progressTintList =
                        android.content.res.ColorStateList.valueOf(Color.parseColor("#34C759"))
                }
            }
            b.tvConfidence.text = if (r != null) "${"%.0f".format(r.confidence)}%" else ""
            b.progressBar.progress = r?.confidence?.toInt() ?: 0
            b.root.setOnClickListener { onClick(e) }
        }
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemHistoryBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun onBindViewHolder(h: VH, p: Int) = h.bind(getItem(p))
    class Diff : DiffUtil.ItemCallback<Email>() {
        override fun areItemsTheSame(o: Email, n: Email) = o.id == n.id
        override fun areContentsTheSame(o: Email, n: Email) = o == n
    }
}
