package com.example.gmailspamdetector.di

import android.content.Context
import androidx.room.Room
import com.example.gmailspamdetector.data.local.AppDatabase
import com.example.gmailspamdetector.data.local.EmailDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "spam_detector_db")
            .fallbackToDestructiveMigration().build()

    @Provides @Singleton
    fun provideEmailDao(db: AppDatabase): EmailDao = db.emailDao()
}
