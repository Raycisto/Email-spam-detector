package com.example.gmailspamdetector.ui.detail

import android.graphics.Color
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.gmailspamdetector.data.model.ScanResult
import com.example.gmailspamdetector.databinding.FragmentDetailBinding
import com.example.gmailspamdetector.utils.toRelativeDateString
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class EmailDetailFragment : Fragment() {
    private var _binding: FragmentDetailBinding? = null
    private val binding get() = _binding!!
    private val viewModel: EmailDetailViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, s: Bundle?
    ): View {
        _binding = FragmentDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val emailId = arguments?.getString("emailId") ?: return
        viewModel.loadEmail(emailId)

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.email.collect { email ->
                    val b = _binding ?: return@collect
                    email ?: return@collect
                    b.tvSubject.text = email.subject.ifEmpty { "(No Subject)" }
                    b.tvSender.text  = "${email.sender} <${email.senderEmail}>"
                    b.tvDate.text    = email.date.toRelativeDateString()
                    b.tvBody.text    = email.body.ifEmpty { email.snippet }
                    email.scanResult?.let { populateRiskCard(it) }
                }
            }
        }
    }

    private fun populateRiskCard(r: ScanResult) {
        val b = _binding ?: return
        val headerColor = when (r.threatLevel) {
            "critical" -> Color.parseColor("#FF1744")
            "high"     -> Color.parseColor("#FF6D00")
            "medium"   -> Color.parseColor("#FF6B35")
            "low"      -> Color.parseColor("#FFAB00")
            else       -> Color.parseColor("#00E676")
        }
        b.riskHeader.setBackgroundColor(headerColor)
        b.tvRiskLabel.text  = r.displayLabel()
        b.tvConfidence.text = "Confidence: ${"%.1f".format(r.confidence)}%"
        b.progressConfidence.progress = r.confidence.toInt()
        b.tvThreatLevel.text = "Threat Level: ${r.threatLevel.uppercase()}"
        b.tvReasons.text = if (r.reasons.isEmpty()) "No suspicious patterns found."
                           else r.reasons.joinToString("\n• ", prefix = "• ")
        b.tvKeywords.text  = if (r.keywords.isEmpty()) "None" else r.keywords.joinToString(", ")
        b.tvUrlCount.text  = "URLs detected: ${r.urlCount}"
        val (recText, recColor) = when (r.recommendation) {
            "delete"    -> "🗑 Delete this email immediately" to Color.parseColor("#FF1744")
            "mark_spam" -> "🚫 Mark as spam"                 to Color.parseColor("#FF6B35")
            "verify"    -> "🔍 Verify sender before replying" to Color.parseColor("#FFAB00")
            else        -> "✅ Safe to read"                  to Color.parseColor("#00E676")
        }
        b.tvRecommendation.text = recText
        b.tvRecommendation.setTextColor(recColor)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
