package com.example.gmailspamdetector.ui.login

import android.content.Intent
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gmailspamdetector.auth.GoogleAuthManager
import com.example.gmailspamdetector.utils.SecurePreferences
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class LoginState {
    object Idle    : LoginState()
    object Loading : LoginState()
    data class Success(val account: GoogleSignInAccount) : LoginState()
    data class Error(val message: String) : LoginState()
}

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val authManager: GoogleAuthManager,
    private val securePrefs: SecurePreferences
) : ViewModel() {

    private val _loginState = MutableStateFlow<LoginState>(LoginState.Idle)
    val loginState: StateFlow<LoginState> = _loginState

    fun checkExistingSession() {
        val account = authManager.getSignedInAccount()
        if (account != null) {
            Log.d("LoginViewModel", "Existing session: ${account.email}")
            _loginState.value = LoginState.Success(account)
        }
    }

    fun getSignInIntent(activity: android.app.Activity): Intent =
        authManager.buildSignInClient().signInIntent

    fun handleSignInResult(task: Task<GoogleSignInAccount>) {
        viewModelScope.launch {
            _loginState.value = LoginState.Loading
            try {
                val account = task.getResult(ApiException::class.java)
                    ?: run { _loginState.value = LoginState.Error("No account returned"); return@launch }
                Log.d("LoginViewModel", "Sign-in success: ${account.email}")
                securePrefs.userEmail = account.email
                securePrefs.userName  = account.displayName
                _loginState.value = LoginState.Success(account)
            } catch (e: ApiException) {
                val msg = "Sign-in failed (code ${e.statusCode})"
                Log.e("LoginViewModel", msg, e)
                _loginState.value = LoginState.Error(msg)
            } catch (e: Exception) {
                Log.e("LoginViewModel", "Unexpected: ${e.message}", e)
                _loginState.value = LoginState.Error("Error: ${e.message}")
            }
        }
    }
}
