package com.example.gmailspamdetector.data.model

data class ScanResult(
    val label: String,
    val confidence: Float,
    val threatLevel: String,
    val reasons: List<String>,
    val keywords: List<String>,
    val urlCount: Int = 0,
    val recommendation: String = "ignore"
) {
    fun displayLabel(): String = when (label) {
        "phishing"   -> "PHISHING"
        "threat"     -> "THREAT"
        "spam"       -> "SPAM"
        "suspicious" -> "SUSPICIOUS"
        else         -> "SAFE"
    }
}
