package com.example.gmailspamdetector.data.remote.dto

import com.google.gson.annotations.SerializedName

data class MessageResponse(
    @SerializedName("id")           val id: String,
    @SerializedName("threadId")     val threadId: String,
    @SerializedName("snippet")      val snippet: String?,
    @SerializedName("payload")      val payload: Payload?,
    @SerializedName("internalDate") val internalDate: String?
)
data class Payload(
    @SerializedName("headers")  val headers: List<Header>?,
    @SerializedName("body")     val body: Body?,
    @SerializedName("parts")    val parts: List<Part>?,
    @SerializedName("mimeType") val mimeType: String?
)
data class Header(
    @SerializedName("name")  val name: String,
    @SerializedName("value") val value: String
)
data class Body(
    @SerializedName("data") val data: String?,
    @SerializedName("size") val size: Int?
)
data class Part(
    @SerializedName("mimeType") val mimeType: String?,
    @SerializedName("body")     val body: Body?,
    @SerializedName("parts")    val parts: List<Part>?
)
