package com.example.gmailspamdetector.ui.login

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.gmailspamdetector.MainActivity
import com.example.gmailspamdetector.databinding.ActivityLoginBinding
import com.example.gmailspamdetector.utils.hide
import com.example.gmailspamdetector.utils.show
import com.example.gmailspamdetector.utils.toast
import com.google.android.gms.auth.api.signin.GoogleSignIn
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

@AndroidEntryPoint
class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val viewModel: LoginViewModel by viewModels()

    private val signInLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        try {
            if (result.data == null) { showIdle(); toast("Sign-in cancelled"); return@registerForActivityResult }
            viewModel.handleSignInResult(GoogleSignIn.getSignedInAccountFromIntent(result.data))
        } catch (e: Exception) {
            Log.e("LoginActivity", "Launcher error", e)
            showIdle(); toast("Sign-in error: ${e.message}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()
        observeState()
        viewModel.checkExistingSession()
        binding.btnGoogleSignIn.setOnClickListener {
            try { signInLauncher.launch(viewModel.getSignInIntent(this)) }
            catch (e: Exception) { toast("Cannot open sign-in: ${e.message}") }
        }
    }

    private fun observeState() {
        lifecycleScope.launch {
            viewModel.loginState.collect { state ->
                when (state) {
                    is LoginState.Idle    -> showIdle()
                    is LoginState.Loading -> showLoading()
                    is LoginState.Success -> navigateToMain()
                    is LoginState.Error   -> {
                        showIdle()
                        val friendly = when {
                            state.message.contains("10")    -> "SHA-1 mismatch — check Google Cloud Console"
                            state.message.contains("12500") -> "Update Google Play Services on your device"
                            state.message.contains("12501") -> "Sign-in cancelled"
                            else -> state.message
                        }
                        toast(friendly)
                    }
                }
            }
        }
    }

    private fun showIdle()    { binding.progressBar.hide();  binding.btnGoogleSignIn.isEnabled = true }
    private fun showLoading() { binding.progressBar.show();  binding.btnGoogleSignIn.isEnabled = false }
    private fun navigateToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
