package com.example.gmailspamdetector.ui.inbox

import android.graphics.Color
import android.view.*
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.gmailspamdetector.R
import com.example.gmailspamdetector.data.model.Email
import com.example.gmailspamdetector.databinding.ItemEmailBinding
import com.example.gmailspamdetector.utils.initials
import com.example.gmailspamdetector.utils.toRelativeDateString

class EmailAdapter(private val onClick: (Email) -> Unit)
    : ListAdapter<Email, EmailAdapter.VH>(Diff()) {

    inner class VH(private val b: ItemEmailBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(email: Email) {
            b.tvSender.text   = email.sender.ifEmpty { email.senderEmail }
            b.tvSubject.text  = email.subject.ifEmpty { "(No Subject)" }
            b.tvPreview.text  = email.snippet.ifEmpty { email.body.take(80) }
            b.tvDate.text     = email.date.toRelativeDateString()
            b.tvInitials.text = email.sender.initials()

            val r = email.scanResult
            when (r?.label) {
                "phishing" -> {
                    b.tvBadge.text = "PHISHING"
                    b.tvBadge.setTextColor(Color.parseColor("#FF3B30"))
                    b.tvBadge.setBackgroundResource(R.drawable.bg_badge_danger)
                }
                "threat" -> {
                    b.tvBadge.text = "THREAT"
                    b.tvBadge.setTextColor(Color.parseColor("#FF3B30"))
                    b.tvBadge.setBackgroundResource(R.drawable.bg_badge_danger)
                }
                "spam" -> {
                    b.tvBadge.text = "SPAM"
                    b.tvBadge.setTextColor(Color.parseColor("#FF9F0A"))
                    b.tvBadge.setBackgroundResource(R.drawable.bg_badge_spam)
                }
                "suspicious" -> {
                    b.tvBadge.text = "SUSPICIOUS"
                    b.tvBadge.setTextColor(Color.parseColor("#FFD60A"))
                    b.tvBadge.setBackgroundResource(R.drawable.bg_badge_suspicious)
                }
                "safe" -> {
                    b.tvBadge.text = "SAFE"
                    b.tvBadge.setTextColor(Color.parseColor("#34C759"))
                    b.tvBadge.setBackgroundResource(R.drawable.bg_badge_safe)
                }
                else -> {
                    b.tvBadge.text = "PENDING"
                    b.tvBadge.setTextColor(Color.parseColor("#888888"))
                    b.tvBadge.setBackgroundColor(Color.parseColor("#14FFFFFF"))
                }
            }
            b.tvConfidence.text = if (r != null) "${"%.0f".format(r.confidence)}%" else ""
            b.root.setOnClickListener { onClick(email) }
        }
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemEmailBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun onBindViewHolder(h: VH, p: Int) = h.bind(getItem(p))
    class Diff : DiffUtil.ItemCallback<Email>() {
        override fun areItemsTheSame(o: Email, n: Email) = o.id == n.id
        override fun areContentsTheSame(o: Email, n: Email) = o == n
    }
}
