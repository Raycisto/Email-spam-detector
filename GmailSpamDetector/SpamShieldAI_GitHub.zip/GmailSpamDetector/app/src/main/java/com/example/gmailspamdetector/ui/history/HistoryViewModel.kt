package com.example.gmailspamdetector.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.gmailspamdetector.data.model.Email
import com.example.gmailspamdetector.repository.GmailRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HistoryViewModel @Inject constructor(private val repository: GmailRepository) : ViewModel() {
    private val _emails = MutableStateFlow<List<Email>>(emptyList())
    val emails: StateFlow<List<Email>> = _emails
    init { viewModelScope.launch { repository.flaggedEmails.collect { _emails.value = it } } }
    fun clearHistory() { viewModelScope.launch { repository.clearHistory() } }
}
