package com.example.gmailspamdetector.data.remote.dto

import com.google.gson.annotations.SerializedName

data class MessageListResponse(
    @SerializedName("messages")          val messages: List<MessageRef>?,
    @SerializedName("nextPageToken")     val nextPageToken: String?,
    @SerializedName("resultSizeEstimate") val resultSizeEstimate: Int?
)

data class MessageRef(
    @SerializedName("id")       val id: String,
    @SerializedName("threadId") val threadId: String
)
