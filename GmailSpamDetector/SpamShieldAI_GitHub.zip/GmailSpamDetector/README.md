# SpamShield AI — Gmail Spam Detector (Android)

A native Android app that scans your Gmail inbox in real time using a Machine Learning backend and flags emails as **SAFE**, **SUSPICIOUS**, or **SPAM** with confidence scores and detailed threat analysis.

---

## Screenshots

| Dashboard | Inbox | Email Detail |
|-----------|-------|--------------|
| Stats: scanned / spam / threats / safe + donut chart | Colour-coded email list with badges and confidence % | Threat level, flagging reasons, suspicious keywords |

---

## Tech Stack

| Layer | Technology |
|-------|------------|
| Android (UI) | Kotlin, MVVM, Navigation Component, ViewBinding |
| Auth | Google Sign-In SDK, OAuth 2.0, Gmail readonly scope |
| Gmail data | Gmail REST API via Retrofit |
| ML Backend | Python · Flask · scikit-learn · Naive Bayes + TF-IDF |
| Local storage | Room database |
| DI | Hilt |
| Charts | MPAndroidChart (donut chart) |

---

## Project Structure

```
GmailSpamDetector/
├── app/src/main/java/com/example/gmailspamdetector/
│   ├── auth/           → GoogleAuthManager.kt (OAuth 2.0)
│   ├── data/
│   │   ├── local/      → Room DB (EmailDao, EmailEntity, AppDatabase)
│   │   ├── model/      → Email.kt, ScanResult.kt
│   │   └── remote/     → GmailApiService.kt + DTOs
│   ├── di/             → Hilt modules (AppModule, DatabaseModule)
│   ├── ml/             → SpamClassifier.kt (calls Flask backend)
│   ├── repository/     → GmailRepository.kt
│   ├── ui/
│   │   ├── dashboard/  → DashboardFragment + ViewModel
│   │   ├── inbox/      → InboxFragment + EmailAdapter + ViewModel
│   │   ├── detail/     → EmailDetailFragment + ViewModel
│   │   ├── history/    → HistoryFragment + HistoryAdapter + ViewModel
│   │   ├── login/      → LoginActivity + ViewModel
│   │   └── settings/   → SettingsFragment
│   ├── utils/          → SecurePreferences.kt, Extensions.kt
│   ├── MainActivity.kt
│   └── SpamDetectorApp.kt
└── app/src/main/res/   → layouts, drawables, nav graph, themes
```

---

## Setup Instructions

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/SpamShieldAI.git
cd SpamShieldAI
```

### 2. Set up Google Cloud + Firebase (required — your own credentials)

> ⚠️ The `google-services.json` in this repo is a **placeholder template**. You must replace it with your own.

1. Go to [Google Cloud Console](https://console.cloud.google.com) → Create a new project
2. Enable the **Gmail API**
3. Go to [Firebase Console](https://console.firebase.google.com) → Add project → Add Android app
4. Package name: `com.example.gmailspamdetector`
5. Register your **SHA-1 fingerprint** (run: `./gradlew signingReport`)
6. Download `google-services.json` → place it in `app/`
7. In Google Cloud Console → APIs & Services → Credentials:
   - Create an **OAuth 2.0 Web Client ID**
   - Copy it into `GoogleAuthManager.kt` replacing `YOUR_WEB_CLIENT_ID.apps.googleusercontent.com`

### 3. Set up the ML Backend

```bash
cd backend/          # (or wherever you have app.py)
pip install -r requirements.txt
python train_model.py        # trains and saves the model
python app.py                # starts Flask on port 5000
```

Update the backend URL in `AppModule.kt` if deploying to Railway/Render instead of localhost.

### 4. Build and run
Open the project in Android Studio → Sync Gradle → Run on device/emulator (API 26+)

---

## ML Model Performance

| Metric | Value |
|--------|-------|
| Accuracy | 98.2% |
| Precision | 99.1% |
| Recall | 94.3% |
| F1 Score | 96.7% |

Dataset: [SMS Spam Collection](https://archive.ics.uci.edu/ml/datasets/SMS+Spam+Collection) — 5,574 labelled messages

---

## How Classification Works

Each email is classified with:
- **Confidence score** (0–100%)
- **Threat level**: LOW / MEDIUM / HIGH
- **Flagging reasons**: e.g. "Contains 40 URLs", "Heavy exclamation use (271)", "Business email from free provider"
- **Suspicious keyword matches**

---

## License
MIT
